const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { Typography, UtilityFragment, Surface, ContentCard, Divider } from '@visa/nova-react';
import type { CSSProperties } from 'react';

const items = [
  { id: 'item-1', label1: 'Item A label 1', label2: 'Item A label 2' },
  { id: 'item-2', label1: 'Item B label 1', label2: 'Item B label 2' },
  { id: 'item-3', label1: 'Item C label 1', label2: 'Item C label 2' },
  { id: 'item-4', label1: 'Item D label 1', label2: 'Item D label 2' },
];

export const DefaultListWithDividers = () => {
  return (
    <UtilityFragment vPadding={4}>
      <ContentCard
        style={
          {
            maxInlineSize: '343px',
            '--v-content-card-border': '0px',
            '--v-content-card-border-radius': '8px',
          } as CSSProperties
        }
        tag="ul"
      >
        {items.map((item, index) => (
          <li key={item.id}>
            <UtilityFragment
              vPaddingHorizontal={8}
              vPaddingVertical={6}
              vFlex
              vAlignItems="center"
              vJustifyContent="between"
              style={{ minBlockSize: '64px' }}
            >
              <Surface>
                <Typography variant="label-large" tag="span">
                  {item.label1}
                </Typography>
                <Typography variant="label-large" tag="span">
                  {item.label2}
                </Typography>
              </Surface>
            </UtilityFragment>
            {index < items.length - 1 && <Divider dividerType="decorative" />}
          </li>
        ))}
      </ContentCard>
    </UtilityFragment>
  );
};
`;export{e as default};
