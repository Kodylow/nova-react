import{j as r}from"./index-CScd3PuE.js";import{S as e}from"./index-D5lCSH_Y.js";import"./index-HGAS5iHI.js";const m=()=>r.jsx(e,{messageType:"error"});export{m as EmptyErrorSectionMessage};
