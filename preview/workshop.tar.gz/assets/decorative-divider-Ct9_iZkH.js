import{j as r}from"./index-CScd3PuE.js";import{D as e}from"./index-BjD5qh5u.js";const t=()=>r.jsx(e,{dividerType:"decorative"});export{t as DecorativeDivider};
