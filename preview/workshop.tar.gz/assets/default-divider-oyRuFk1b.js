import{j as r}from"./index-CScd3PuE.js";import{D as t}from"./index-BjD5qh5u.js";const e=()=>r.jsx(t,{});export{e as DefaultDivider};
