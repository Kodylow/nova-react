const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { Surface, Utility } from '@visa/nova-react';
import type { CSSProperties } from 'react';

export const DefaultMargin = () => {
  return (
    <Utility vFlex>
      <Utility vFlex style={{ background: 'var(--palette-default-surface-highlight)' } as CSSProperties}>
        <Utility
          element={<Surface />}
          vMargin={20}
          style={{ border: '1px dashed var(--palette-default-active-subtle)' } as CSSProperties}
        >
          Content Area
        </Utility>
      </Utility>
    </Utility>
  );
};
`;export{e as default};
