import{j as r}from"./index-CScd3PuE.js";import{F as o}from"./index-C3jP92JP.js";import"./index-HGAS5iHI.js";const e=()=>r.jsx(o,{messageType:"error"});export{e as EmptyErrorFlag};
