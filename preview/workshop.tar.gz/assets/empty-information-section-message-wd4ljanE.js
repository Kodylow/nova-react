import{j as o}from"./index-CScd3PuE.js";import{S as t}from"./index-D5lCSH_Y.js";import"./index-HGAS5iHI.js";const m=()=>o.jsx(t,{});export{m as EmptyInformationSectionMessage};
