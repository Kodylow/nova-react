import{j as r}from"./index-CScd3PuE.js";import{S as e}from"./index-BiDH-XKB.js";const a=()=>r.jsx(e,{children:"Example"});export{a as DefaultSurface};
