import{j as t,U as e}from"./index-CScd3PuE.js";const i=()=>t.jsx(e,{vFlex:!0,vGap:4,children:"This is a flex container"});export{i as DefaultFlex};
