import{j as t}from"./index-CScd3PuE.js";import{B as r}from"./index-BSYps_Tx.js";const i=()=>t.jsx(r,{children:"Primary action"});export{i as DefaultButton};
