import{j as r}from"./index-CScd3PuE.js";import{B as e}from"./index-CyNLZtm2.js";const o=()=>r.jsx(e,{badgeType:"critical",badgeVariant:"number",children:"12345"});export{o as BadgeNumberLong};
