import{j as r}from"./index-CScd3PuE.js";import{B as e}from"./index-CyNLZtm2.js";const i=()=>r.jsx(e,{badgeType:"critical",badgeVariant:"number",children:"3"});export{i as BadgeNumberDefault};
