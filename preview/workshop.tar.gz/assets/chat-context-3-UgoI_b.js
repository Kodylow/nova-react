import{r as t}from"./index-CScd3PuE.js";const e={responses:[],setResponses:()=>{}},o=t.createContext(e);export{o as C};
