import{j as r}from"./index-CScd3PuE.js";import{S as e}from"./index-BiDH-XKB.js";const o=()=>r.jsx(e,{surfaceType:"alternate",children:"Example"});export{o as AlternateSurface};
