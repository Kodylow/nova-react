const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { UtilityFragment, Typography, Surface, Switch, SwitchLabel } from '@visa/nova-react';

const id = 'disabled-switch-list-item';

export const DisabledSwitchListItem = () => {
  return (
    <ul style={{ maxInlineSize: '343px' }}>
      <UtilityFragment
        vPaddingHorizontal={8}
        vPaddingVertical={6}
        vFlex
        vAlignItems="center"
        vJustifyContent="between"
        style={{ minBlockSize: '64px' }}
      >
        <Surface tag="li">
          <SwitchLabel htmlFor={\`\${id}-switch\`}>
            <Typography variant="label-large" tag="span">
              Item label
            </Typography>
          </SwitchLabel>
          <Switch disabled id={\`\${id}-switch\`} name="disabled-switch-list-item" />
        </Surface>
      </UtilityFragment>
    </ul>
  );
};
`;export{e as default};
