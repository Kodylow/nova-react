import{j as i}from"./index-CScd3PuE.js";import{L as r}from"./index-BoLn5TgT.js";const n=()=>i.jsx(r,{disabled:!0,role:"link",children:"Destination label"});export{n as DisabledLink};
