const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { Input, InputContainer, Label, Utility } from '@visa/nova-react';

// TIP: Customize this ID, pass it as a prop, or auto-generate it with useId() from @react
const id = 'disabled-time-selector';

export const DisabledTimeSelector = () => {
  return (
      <Utility vFlex vGap="4" vFlexCol vFlexGrow>
        <Label htmlFor={\`\${id}-time\`}>Label (required)</Label>
        <InputContainer>
          <Input id={\`\${id}-time\`} required type="time" disabled/>
        </InputContainer>
      </Utility>
  );
};
`;export{e as default};
