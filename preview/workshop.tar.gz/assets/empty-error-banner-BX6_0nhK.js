import{j as r}from"./index-CScd3PuE.js";import{B as o}from"./index-C91Xc2UG.js";import"./index-HGAS5iHI.js";const s=()=>r.jsx(o,{messageType:"error"});export{s as EmptyErrorBanner};
