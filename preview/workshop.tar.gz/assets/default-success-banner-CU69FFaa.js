const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { MessageIcon, VisaCloseTiny } from '@visa/nova-icons-react';
import { Banner, BannerCloseButton, BannerContent, Typography } from '@visa/nova-react';

export const DefaultSuccessBanner = () => {
  return (
    <Banner messageType="success">
      <MessageIcon messageType="success" />
      <BannerContent className="v-pl-2 v-pb-2">
        <Typography>This is required text that describes the banner in more detail.</Typography>
      </BannerContent>
      <BannerCloseButton>
        <VisaCloseTiny />
      </BannerCloseButton>
    </Banner>
  );
};
`;export{e as default};
