import{j as r}from"./index-CScd3PuE.js";import{L as t}from"./index-BoLn5TgT.js";const e=()=>r.jsx(t,{href:"./link",children:"Destination label"});export{e as DefaultLink};
