const e=`/**
 *              © 2025-2026 Visa
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
import { VisaClearAltTiny } from '@visa/nova-icons-react';
import { Button, Chip } from '@visa/nova-react';

export const DefaultRemovableChip = () => {
  return (
    <Chip>
      <span>Label</span>
      <Button aria-label="clear Label" colorScheme="tertiary" iconButton subtle>
        <VisaClearAltTiny />
      </Button>
    </Chip>
  );
};
`;export{e as default};
