import{j as o}from"./index-CScd3PuE.js";import{F as r}from"./index-C3jP92JP.js";import"./index-HGAS5iHI.js";const s=()=>o.jsx(r,{});export{s as EmptyInformationFlag};
