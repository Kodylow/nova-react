import{j as t}from"./index-CScd3PuE.js";import{B as r}from"./index-BSYps_Tx.js";const n=()=>t.jsx(r,{alternate:!0,children:"Primary action"});export{n as AlternateButton};
